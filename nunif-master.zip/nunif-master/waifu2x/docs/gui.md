# waifu2x GUI

```
python -m waifu2x.gui
```
or
```
python -m waifu2x.gui --lang en_US
```

![waifu2x-gui](https://github.com/nagadomi/nunif/assets/287255/2613b8d5-c735-4b31-aa63-1c02ee620331)

It requires `wxpython` to be installed.

The screen session is stored in `tmp/waifu2x-gui.cfg`. If you want to reset it, delete it.
