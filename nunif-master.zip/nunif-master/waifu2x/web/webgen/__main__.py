if __name__ == "__main__":
    from .gen import main
    main()
