# webgen

From [waifu2x/webgen](https://github.com/nagadomi/waifu2x/tree/master/webgen)

## Generating web pages

```
python3 gen.py
```

View at `../public_html`.

## Adding a translation file

1. Adding a translation file to `./locales`
2. Run `python3 gen.py`
