from .cache import purge_cache_all


def main():
    purge_cache_all()


if __name__ == "__main__":
    main()
