# Text Resource

Text resources and their metadata for generating synthetic text image data.

Currently only Japanese Font is supported.

# Word/Vocabulary Dictionary

## UniDic

https://clrd.ninjal.ac.jp/unidic/

## mecab-ipadic-NEologd

https://github.com/neologd/mecab-ipadic-neologd

## american-english

/usr/share/dict/american-english

# Text Data

## Aozora Bunko

https://www.aozora.gr.jp/

Official Repository

https://github.com/aozorabunko/aozorabunko

Text Only

https://github.com/aozorahack/aozorabunko_text

## Project Gutenberg

https://www.gutenberg.org/

